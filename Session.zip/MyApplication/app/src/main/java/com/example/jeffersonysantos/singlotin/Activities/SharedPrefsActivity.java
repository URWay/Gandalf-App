package com.example.jeffersonysantos.singlotin.Activities;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.jeffersonysantos.singlotin.R;

public class SharedPrefsActivity extends AppCompatActivity {

    EditText editNome, editEmail;
    Button buttonSave, buttonLimpara, buttonReiniciar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shared_prefs);

        editNome = (EditText) findViewById(R.id.editNome);
        editEmail = (EditText) findViewById(R.id.editEmail);
        buttonSave = (Button) findViewById(R.id.buttonSave);
        buttonLimpara = (Button) findViewById(R.id.buttonLimpara);
        buttonReiniciar = (Button) findViewById(R.id.buttonReiniciar);

        SharedPreferences prefs = getSharedPreferences("DadosSuperApp", MODE_PRIVATE);
        String nome = prefs.getString("name", null);
        String email = prefs.getString("email", null);

        if(nome != null){
            editNome.setText(nome);
        }

        if(email != null){
            editEmail.setText(email);
        }

        if(nome == null && email == null){
            Toast toast = Toast.makeText(getApplicationContext(), "Não há dados salvos", Toast.LENGTH_SHORT);
            toast.show();
        } else {
            Toast toast = Toast.makeText(getApplicationContext(), "Dados salvos recarregados", Toast.LENGTH_SHORT);
            toast.show();
        }

        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences prefs = getSharedPreferences("DadosSuperApp", MODE_PRIVATE);
                SharedPreferences.Editor editor = prefs.edit();
                editor.putString("name", editNome.getText().toString());
                editor.putString("email", editEmail.getText().toString());
                editor.apply();

                Toast toast = Toast.makeText(getApplicationContext(), "Dados salvos", Toast.LENGTH_SHORT);
                toast.show();
            }
        });

        buttonLimpara.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface dialog, int whick) {
                        switch (whick) {
                            case DialogInterface.BUTTON_POSITIVE:
                                SharedPreferences prefs = getSharedPreferences("DadosSuperApp", MODE_PRIVATE);
                                SharedPreferences.Editor editor = prefs.edit();
                                editor.putString("name", null);
                                editor.putString("email", null);
                                editor.apply();

                                editNome.setText("");
                                editEmail.setText("");

                                Toast toast = Toast.makeText(getApplicationContext(), "Dados apagados", Toast.LENGTH_SHORT);
                                toast.show();

                                break;

                            case DialogInterface.BUTTON_NEGATIVE:
                                break;
                        }
                    }
                };

                AlertDialog.Builder builder = new AlertDialog.Builder(SharedPrefsActivity.this);
                builder.setMessage("Configrma remoção de todos os dados?").setTitle("Apagar dados").setPositiveButton("Sim", dialogClickListener).setNegativeButton("Não", dialogClickListener).show();
            }
        });

        buttonReiniciar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SharedPrefsActivity.this, SharedPrefsActivity.class);
                startActivity(intent);
                finish();
            }
        });

    }
}
