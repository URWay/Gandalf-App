package com.example.jeffersonysantos.singlotin.Activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.jeffersonysantos.singlotin.R;
import com.example.jeffersonysantos.singlotin.model.Cliente;
import com.example.jeffersonysantos.singlotin.singletons.ClienteSingleton;

public class SingletonActivity extends AppCompatActivity {

    EditText nome, email;
    Button buttonSave, buttonGo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_singleton);

        nome = (EditText) findViewById(R.id.nome);
        email = (EditText) findViewById(R.id.email);
        buttonSave = (Button) findViewById(R.id.buttonSave);
        buttonGo = (Button) findViewById(R.id.buttonGo);

        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cliente cliente = new Cliente();
                cliente.setNome(nome.getText().toString());
                cliente.setEmail(email.getText().toString());
                ClienteSingleton.getInstance().setCliente(cliente);

                Toast toast = Toast.makeText(getApplicationContext(), "Dados salvos", Toast.LENGTH_SHORT);
                toast.show();
            }
        });

        buttonGo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SingletonActivity.this, SingletonValuesActivity.class);
                startActivity(intent);
            }
        });

    }
}
