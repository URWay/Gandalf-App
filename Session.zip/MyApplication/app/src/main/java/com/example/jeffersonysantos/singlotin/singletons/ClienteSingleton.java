package com.example.jeffersonysantos.singlotin.singletons;

import com.example.jeffersonysantos.singlotin.model.Cliente;

public class ClienteSingleton {

    // Instância única da classe
    private static final ClienteSingleton INSTANCE  = new ClienteSingleton();

    // Atributos para armazenar elementos desejados
    private Cliente cliente = null;

    // Contrutor privado do Singleton
    private ClienteSingleton() {

    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente){
        this.cliente = cliente;
    }

    // Método de obtenção de instância única do Singleton
    public static ClienteSingleton getInstance(){
        return INSTANCE;
    }
}
