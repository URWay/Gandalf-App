package com.example.jeffersonysantos.singlotin.Activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.jeffersonysantos.singlotin.R;
import com.example.jeffersonysantos.singlotin.model.Cliente;
import com.example.jeffersonysantos.singlotin.singletons.ClienteSingleton;

public class SingletonValuesActivity extends AppCompatActivity {

    TextView textNome, textEmail;
    Button buttonVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_singleton_values);

        textNome = (TextView) findViewById(R.id.textNome);
        textEmail = (TextView) findViewById(R.id.textEmail);
        buttonVoltar = (Button) findViewById(R.id.buttonVoltar);

        Cliente cli = ClienteSingleton.getInstance().getCliente();

        if(cli != null){
            textNome.setText(cli.getNome());
            textEmail.setText(cli.getEmail());
        } else {
            Toast toast = Toast.makeText(getApplicationContext(), "Não há dados", Toast.LENGTH_SHORT);
            toast.show();
        }

        buttonVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SingletonValuesActivity.this, SingletonActivity.class);
                startActivity(intent);
            }
        });

    }
}
